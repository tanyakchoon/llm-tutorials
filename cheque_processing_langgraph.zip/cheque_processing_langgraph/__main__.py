import os
import uuid
import json
from typing import TypedDict, List, Any
from pathlib import Path

import cv2
import numpy as np
import pandas as pd
from dotenv import load_dotenv
from langgraph.graph import StateGraph, END
from langchain_google_genai import ChatGoogleGenerativeAI

from .image_enhancement.enhancer import enhance_brightness_contrast, correct_skew, llm_check_readability
from .processing.ocr_extraction import llm_extract_cheque_data_from_image
from .processing.validation import validate_account_details, trigger_lien_marking
from .fraud_detection.tampering_detection import llm_detect_tampering
from .fraud_detection.behavior_analysis import llm_analyze_historical_behavior
# === IMPORT THE NEW PROGRAMMATIC SIGNATURE COMPARISON MODULE ===
from .fraud_detection.signature_comparison import compare_signatures_ssim

class ChequeState(TypedDict):
    image: np.ndarray
    cheque_data: dict
    signature_image: np.ndarray | None
    amount_in_words: str | None
    audit_trail: Any
    is_readable: bool
    fraud_detected: bool
    final_decision: str
    feedback: List[str]

def build_graph(reference_signature_image: np.ndarray):
    """Builds and returns the LangGraph compiled workflow."""
    load_dotenv()
    llm = ChatGoogleGenerativeAI(model="gemini-2.5-flash", temperature=0)
    json_llm = llm.bind(response_mime_type="application/json")

    historical_transactions = pd.DataFrame({
        'account_id': ['123456678', '123456678', 'ACC98765'],
        'amount': [150.00, 250.50, 3000.00],
        'payee': ['Apple Tan', 'Some Company', 'car dealership']
    })

    def start_processing(state: ChequeState) -> ChequeState:
        from .audit.trail import AuditTrail
        cheque_id = f"cheque-{uuid.uuid4().hex[:8]}"
        audit_trail = AuditTrail(cheque_id)
        audit_trail.log_step("Start", "Success", "Image data received.")
        return {**state, "audit_trail": audit_trail, "feedback": []}

    def check_image_quality(state: ChequeState) -> ChequeState:
        is_readable, msg = llm_check_readability(state["image"], json_llm)
        if not is_readable:
            state["audit_trail"].highlight_anomaly("Image Quality", msg)
            return {**state, "is_readable": False}
        state["audit_trail"].log_step("Image Quality Check", "Success", "Gemini approved.")
        image = enhance_brightness_contrast(state["image"])
        image = correct_skew(image)
        state["audit_trail"].log_step("Image Enhancement", "Success", "Image enhanced.")
        return {**state, "image": image, "is_readable": True}

    def extract_data(state: ChequeState) -> ChequeState:
        data = llm_extract_cheque_data_from_image(state["image"], json_llm)
        if "error" in data or not all(k in data for k in ["amount", "payee", "signature_image"]):
            err_msg = data.get("error", "Gemini Vision failed to extract all key fields.")
            state["audit_trail"].log_step("OCR Extraction", "Failed", err_msg)
            return {**state, "final_decision": "MANUAL_REVIEW"}
        state["audit_trail"].log_step("OCR Extraction", "Success", "Extracted Data.")
        return {**state, "cheque_data": data, "signature_image": data.get("signature_image"), "amount_in_words": data.get("amount_in_words")}

    def run_fraud_detection(state: ChequeState) -> ChequeState:
        fraud_found = False
        audit_trail = state["audit_trail"]
        
        is_tampered, msg = llm_detect_tampering(state["image"], json_llm)
        if is_tampered:
            audit_trail.highlight_anomaly("Tampering Detection", msg)
            fraud_found = True
            
        is_anomalous, msg = llm_analyze_historical_behavior(state["cheque_data"], historical_transactions, json_llm)
        if is_anomalous:
            audit_trail.highlight_anomaly("Behavior Analysis", msg)
            fraud_found = True

        cheque_signature = state.get("signature_image")
        if cheque_signature is not None:
            try:
                # === CALL THE NEW SSIM FUNCTION ===
                match, reason, score = compare_signatures_ssim(cheque_signature, reference_signature_image)
                
                if not match:
                    audit_trail.highlight_anomaly("Signature Verification", reason)
                    fraud_found = True
                else:
                    audit_trail.log_step("Signature Verification", "Success", reason)
            except Exception as e:
                audit_trail.highlight_anomaly("Signature Verification", f"Error during comparison: {e}")
        
        audit_trail.log_step("Fraud Detection", "Completed", f"Fraud found: {fraud_found}")
        return {**state, "fraud_detected": fraud_found}

    def validate_and_process(state: ChequeState) -> ChequeState:
        data = state["cheque_data"]
        is_valid, msg = validate_account_details(data.get("account_number", ""))
        if not is_valid:
            state["audit_trail"].highlight_anomaly("Account Validation", msg)
            return {**state, "final_decision": "REJECT"}
        state["audit_trail"].log_step("Account Validation", "Success", "Account is valid.")
        needs_lien, msg = llm_predict_lien_necessity(data, json_llm)
        if needs_lien:
            state["audit_trail"].log_step("Lien Prediction", "Recommended", msg)
            success, lien_msg = trigger_lien_marking(data["account_number"], data["amount"])
            state["audit_trail"].log_step("Lien Marking", "Success" if success else "Failed", lien_msg)
        state["feedback"].append("Cheque processed successfully.")
        return {**state, "final_decision": "APPROVE"}
        
    def route_after_start(state: ChequeState): return "check_image_quality"
    def route_after_quality_check(state: ChequeState): return END if not state.get("is_readable") else "extract_data"
    def route_after_extraction(state: ChequeState): return END if state.get("final_decision") == "MANUAL_REVIEW" else "run_fraud_detection"
    def route_after_fraud_check(state: ChequeState): return "manual_review" if state.get("fraud_detected") else "validate_and_process"

    workflow = StateGraph(ChequeState)
    workflow.add_node("start", start_processing)
    workflow.add_node("check_image_quality", check_image_quality)
    workflow.add_node("extract_data", extract_data)
    workflow.add_node("run_fraud_detection", run_fraud_detection)
    workflow.add_node("validate_and_process", validate_and_process)
    workflow.add_node("manual_review", lambda state: {**state, "final_decision": "MANUAL_REVIEW"})
    workflow.set_entry_point("start")
    workflow.add_conditional_edges("start", route_after_start)
    workflow.add_conditional_edges("check_image_quality", route_after_quality_check)
    workflow.add_conditional_edges("extract_data", route_after_extraction)
    workflow.add_conditional_edges("run_fraud_detection", route_after_fraud_check)
    workflow.add_edge("validate_and_process", END)
    workflow.add_edge("manual_review", END)
    return workflow.compile(), llm

def main():
    print("Initializing Cheque Processing System for command-line test...")
    try:
        project_root = str(Path(__file__).parent.parent.resolve())
    except NameError:
        project_root = os.getcwd()

    dbs_cheque_path = Path(project_root) / "dbs_cheque.png"
    ref_sig_path = Path(project_root) / "reference_signature.png"
    if not dbs_cheque_path.exists() or not ref_sig_path.exists():
        print(f"FATAL: Ensure 'dbs_cheque.png' and 'reference_signature.png' exist in {project_root}")
        return
        
    cheque_image_data = cv2.imread(str(dbs_cheque_path))
    reference_signature_image = cv2.imread(str(ref_sig_path))

    app, text_llm = build_graph(reference_signature_image=reference_signature_image)
    initial_state = {"image": cheque_image_data}
    
    print(f"\nStarting Cheque Processing Workflow...")
    final_state = app.invoke(initial_state)

    print("\n\n" + "=" * 50)
    print("           FINAL CHEQUE PROCESSING OUTCOME")
    print("=" * 50)
    print(f"Final Decision: {final_state.get('final_decision', 'N/A')}")
    print(f"Feedback: {final_state.get('feedback')}")
    if final_state.get("audit_trail"):
        summary = final_state["audit_trail"].generate_llm_summary_report(text_llm)
        print("\n--- Gemini-Generated Audit Summary ---")
        print(summary)
    print("=" * 50)

if __name__ == "__main__":
    main()