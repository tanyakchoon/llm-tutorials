import cv2
import numpy as np
from skimage.metrics import structural_similarity as ssim

def preprocess_for_comparison(image: np.ndarray, target_size=(300, 150)) -> np.ndarray:
    """
    Preprocesses a signature image for comparison by resizing and converting to grayscale.
    """
    # Resize the image to a standard size
    resized = cv2.resize(image, target_size)
    # Convert to grayscale
    gray = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY)
    return gray

def compare_signatures_ssim(
    cheque_signature: np.ndarray,
    reference_signature: np.ndarray,
    threshold: float = 0.30
) -> (bool, str, float):
    """
    Compares two signature images using the Structural Similarity Index (SSIM).

    Args:
        cheque_signature: The signature cropped from the cheque.
        reference_signature: The signature on file.
        threshold: The similarity score above which signatures are considered a match.

    Returns:
        A tuple containing:
        - bool: True if signatures match, False otherwise.
        - str: A human-readable reason for the decision.
        - float: The actual SSIM score.
    """
    print("INFO: Comparing signatures using programmatic SSIM method...")

    if cheque_signature is None or reference_signature is None:
        return False, "One of the signature images is missing.", 0.0

    # Preprocess both images to make them comparable
    cheque_sig_processed = preprocess_for_comparison(cheque_signature)
    ref_sig_processed = preprocess_for_comparison(reference_signature)

    # Compute the Structural Similarity Index
    try:
        score, _ = ssim(cheque_sig_processed, ref_sig_processed, full=True)
    except ValueError as e:
        # This can happen if images are not the same size after processing, which shouldn't occur here.
        print(f"ERROR: Could not compute SSIM. {e}")
        return False, f"Image processing error during SSIM: {e}", 0.0

    print(f"INFO: Signature comparison SSIM score: {score:.4f}")

    # Compare the score against the threshold
    if score > threshold:
        match = True
        reason = f"Signatures are structurally similar (Score: {score:.2f} > Threshold: {threshold:.2f})"
    else:
        match = False
        reason = f"Signatures are not structurally similar (Score: {score:.2f} <= Threshold: {threshold:.2f})"

    return match, reason, score