import pandas as pd
from langchain_core.prompts import ChatPromptTemplate
from langchain_google_genai import ChatGoogleGenerativeAI

from ..utils import parse_json_from_response

def llm_analyze_historical_behavior(cheque_data: dict, historical_data: pd.DataFrame, llm: ChatGoogleGenerativeAI) -> (bool, str):
    """
    Uses an LLM to analyze cheque data against historical context for anomalies,
    with robust JSON parsing and key standardization.
    """
    print("INFO: Analyzing historical behavior using Gemini...")
    account_id = cheque_data.get("account_number")
    amount = cheque_data.get("amount")

    if not (account_id and amount):
        return False, "Insufficient data for behavior analysis."

    user_transactions = historical_data[historical_data['account_id'] == account_id]
    
    if user_transactions.empty:
        return False, "No historical data for this account."

    # Create a summary of historical data for the LLM
    history_summary = f"""
    - Average transaction amount: ${user_transactions['amount'].mean():.2f}
    - Maximum transaction amount: ${user_transactions['amount'].max():.2f}
    - Transaction count in last 30 days: {len(user_transactions)}
    - Frequent Payees: {list(user_transactions['payee'].value_counts().head(3).index)}
    """
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a fraud detection analyst. Your task is to determine if a new transaction is anomalous based on historical data. Respond in JSON format."),
        ("human", """
        Here is the historical transaction summary for an account:
        {history}

        And here is the new cheque transaction to analyze:
        - Amount: ${amount}
        - Payee: {payee}

        Is this transaction unusual or potentially fraudulent? Provide a brief justification.
        Respond with a JSON object with two keys:
        - "is_anomalous": boolean
        - "reason": string
        """)
    ])

    chain = prompt | llm
    try:
        response = chain.invoke({
            "history": history_summary,
            "amount": amount,
            "payee": cheque_data.get("payee", "N/A")
        })
        result = parse_json_from_response(response.content)
        
        if result:
            # Standardize keys to lowercase to handle model inconsistencies (e.g., "Is_Anomalous")
            standardized_result = {k.lower(): v for k, v in result.items()}
            
            # Perform check on the standardized dictionary
            if "is_anomalous" in standardized_result and "reason" in standardized_result:
                return standardized_result["is_anomalous"], standardized_result["reason"]

        # This block will be reached if parsing fails OR if the required keys are missing.
        print(f"ERROR: Model returned incomplete/unparseable JSON from behavior analysis. Raw: {response.content}")
        return True, "Analysis failed due to model response error, flagging for review."

    except Exception as e:
        print(f"ERROR: API call failed during behavior analysis: {e}")
        return True, "Analysis failed due to API error, flagging for review."