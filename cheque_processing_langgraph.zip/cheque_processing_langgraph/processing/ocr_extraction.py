import cv2
import numpy as np
import json
import base64
import io
from PIL import Image
from langchain_core.messages import HumanMessage
from langchain_google_genai import ChatGoogleGenerativeAI

def convert_to_pil_image(image_array: np.ndarray) -> Image.Image:
    """Converts a BGR numpy array from OpenCV to an RGB PIL Image."""
    return Image.fromarray(cv2.cvtColor(image_array, cv2.COLOR_BGR2RGB))

def encode_pil_to_base64_data_uri(pil_image: Image.Image) -> str:
    """Encodes a PIL image to a Base64 data URI."""
    buffered = io.BytesIO()
    pil_image.save(buffered, format="PNG")
    img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
    return f"data:image/png;base64,{img_str}"

def llm_extract_cheque_data_from_image(image: np.ndarray, llm: ChatGoogleGenerativeAI) -> dict:
    """
    Extracts structured data, including the signature as a cropped image, using Gemini 1.5 Pro.
    """
    print("INFO: Extracting data and signature location using Google Gemini 1.5 Pro Vision...")
    pil_image = convert_to_pil_image(image)
    data_uri = encode_pil_to_base64_data_uri(pil_image)

    # Updated prompt to ask for amount in words and signature bounding box
    prompt = HumanMessage(
        content=[
            {
                "type": "text",
                "text": """
                You are a highly accurate bank teller AI. Analyze the attached cheque image and extract the following fields.

                Your instructions are:
                1.  **Payee**: Identify the handwritten recipient's name next to "Pay".
                2.  **Date**: Extract the 6 digits from the date boxes (DDMMYY format).
                3.  **Amount**: Extract the numeric value. IMPORTANT: The cheque uses a comma as a decimal separator (e.g., "1,628,99" should be 1628.99).
                4.  **Amount in Words**: Extract the handwritten text amount next to "Singapore Dollars".
                5.  **Account Number**: Extract the account number from the MICR line at the bottom.
                6.  **Signature Bounding Box**: Provide the coordinates of the signature box as a JSON object with relative values (0.0 to 1.0) for `{"x_min", "y_min", "x_max", "y_max"}`. The signature is above "Please sign above this line".

                Return everything as a single, clean JSON object.
                Example:
                {
                    "payee": "Anthony Tan",
                    "amount": 1222.99,
                    "date": "221018",
                    "amount_in_words": "One thousand six hundred twenty eight dollars and eighty cents",
                    "account_number": "177772",
                    "signature_bbox": {"x_min": 0.75, "y_min": 0.65, "x_max": 0.95, "y_max": 0.75}
                }
                """,
            },
            {
                "type": "image_url",
                "image_url": data_uri
            },
        ]
    )

    try:
        response = llm.invoke([prompt])
        data = json.loads(response.content)
        
        # --- Crop the Signature ---
        signature_image = None
        if "signature_bbox" in data:
            h, w, _ = image.shape
            bbox = data["signature_bbox"]
            x1 = int(bbox['x_min'] * w)
            y1 = int(bbox['y_min'] * h)
            x2 = int(bbox['x_max'] * w)
            y2 = int(bbox['y_max'] * h)
            # Add a small padding
            padding = 5
            signature_image = image[y1-padding:y2+padding, x1-padding:x2+padding]
            print(f"INFO: Signature successfully cropped from image.")
        
        # Add the cropped image to the data dictionary to be returned
        data["signature_image"] = signature_image

        if "amount" in data and isinstance(data["amount"], (str, int)):
            data["amount"] = float(data["amount"])

        print(f"INFO: Gemini successfully extracted data.")
        print(f"INFO: Data extracted  : {data}")
        return data
        
    except Exception as e:
        import traceback
        print(f"ERROR: Failed to extract or parse data with Gemini Vision: {e}")
        traceback.print_exc()
        return {"error": str(e)}