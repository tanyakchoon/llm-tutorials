def validate_account_details(account_number: str) -> (bool, str):
    """
    Mock function to validate account details via a banking API.
    """
    print(f"INFO: Validating account details for {account_number} via mock API...")
    if account_number and "ACC" in account_number:
        return True, "Account details are valid."
    return False, "Invalid or closed account."

def trigger_lien_marking(account_number: str, amount: float) -> (bool, str):
    """
    Mock function to trigger a lien marking via an API.
    """
    print(f"INFO: Triggering lien marking for {amount} on account {account_number}...")
    # In a real scenario, this would be an API call to a core banking system.
    return True, f"Lien of {amount} successfully marked on account {account_number}."